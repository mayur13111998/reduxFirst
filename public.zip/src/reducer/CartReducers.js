const product = {
  total: 0,
  customer_id: null,
  products: [],
};

const CartReducer = (state = product, action) => {
  switch (action.type) {
    case "Add_ORDER_ITEMS":
      let {
        product_id,
        product_name,
        product_price,
        quantity,
        product_total_price,
      } = action.payload;
      let total_price = state.total + product_total_price;
      return {
        ...state,
        total: total_price,
        products: [
          ...state.products,
          {
            product_id,
            product_name,
            product_price,
            quantity,
            product_total_price,
          },
        ],
      };
    case "REMOVE_PRODUCT":
      return [...state.filter((id) => id.product_id !== action.payload)];
    default:
      return state;
  }
};
export default CartReducer;
