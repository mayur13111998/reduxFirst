export const addproduct = (data) => {
  return {
    type: "Add_ORDER_ITEMS",
    payload: data,
  };
};

export const fd = () => {
  return {
    type: "REMOVE_PRODUCT",
    payload: 4,
  };
};

export const fetchTotal = () => {
  return {
    type: "FETCH_TOTAL",
  };
};
