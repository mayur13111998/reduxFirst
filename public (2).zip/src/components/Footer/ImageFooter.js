import React from "react";

const ImageFooter = ({ src }) => {
  return <img src={src} atl="image" width="100%" />;
};

export default ImageFooter;
