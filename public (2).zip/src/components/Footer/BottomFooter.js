import React from "react";

const BottomFooter = () => {
  return (
    <div className="container-fluid bottom_footer">
      <div className="container">
        <div className="text-right">©2021 presented by MAYUR </div>
      </div>
    </div>
  );
};

export default BottomFooter;
