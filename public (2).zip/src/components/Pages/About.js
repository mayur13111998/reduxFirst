import React from "react";

const About = () => {
  return <div>about</div>;
};

export default About;
