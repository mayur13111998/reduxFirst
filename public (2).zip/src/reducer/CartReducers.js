const product = {
  total: 0,
  customer_id: 0,
  products: [],
};

const CartReducer = (state = product, action) => {
  switch (action.type) {
    case "ADD_CUSTOMER_ID":
      return { ...state, customer_id: Number(action.payload) };
    case "Add_ORDER_ITEMS":
      let {
        product_id,
        product_name,
        product_price,
        quantity,
        product_total_price,
      } = action.payload;
      let total_product_amount = quantity * product_price;
      let total_price = state.total + total_product_amount;
      if (state.products.length === 0) {
        return {
          ...state,
          total: total_price,
          products: [
            ...state.products,
            {
              product_id,
              product_name,
              product_price,
              quantity,
              product_total_price: total_product_amount,
            },
          ],
        };
      } else {
        let productAll = state.products;
        let find2 = false;
        let indexmain = 0;
        productAll.map((data, index) => {
          if (data.product_id == product_id) {
            find2 = true;
            indexmain = index;
            let pri = quantity * state.products[indexmain].product_price;

            let total_main =
              state.total - state.products[indexmain].product_total_price;
            state.total = total_main + pri;
            state.products[indexmain].quantity = quantity;
            state.products[indexmain].product_total_price = pri;
          }
        });

        if (find2) {
          return state;
        } else {
          return {
            ...state,
            total: total_price,
            products: [
              ...state.products,
              {
                product_id,
                product_name,
                product_price,
                quantity,
                product_total_price,
              },
            ],
          };
        }
      }
    case "REMOVE_PRODUCT":
      let product_price2 = {
        ...state,
        products: [
          ...state.products.filter((id) => id.product_id === action.payload),
        ],
      };
      let total2 = state.total - product_price2.products[0].product_total_price;
      return {
        ...state,
        total: total2,
        products: [
          ...state.products.filter((id) => id.product_id !== action.payload),
        ],
      };
    case "CART_PRODUCT_QUANTITY":
      let qty = state.products[action.payload].quantity;
      let to = state.products[action.payload].product_total_price;
      state.total = state.total - to;
      let pri = state.products[action.payload].product_price;
      state.products[action.payload].quantity = qty - 1;
      state.products[action.payload].product_total_price =
        state.products[action.payload].quantity * pri;
      state.total =
        state.total + state.products[action.payload].product_total_price;
      console.log(pri);
      console.log(qty, "mayu");
      return state;
    default:
      return state;
  }
};
export default CartReducer;
